//40223028 - Zahra Heydari
//HW08
#include <stdio.h>
#include <stdlib.h>
struct time
{
    int min;
    int sec;
};
struct runner
{
    char firstName[30];
    char lastName[30];
    char ID[10];
    struct time *record;
    struct time runningTime;
};


// Function to compare two times
// 1 means t1 > t2 // 0 means t1 < t2 // -1 means t1 = t2
int compareTimes(struct time t1, struct time t2)
{
    if (t1.min < t2.min)
        return 0;
    else if (t1.min > t2.min)
        return 1;
    else {
        if (t1.sec < t2.sec)
            return 0;
        else if (t1.sec > t2.sec)
            return 1;
        else
            return -1;
    }
}

int main()
{
    int n;
    printf("Enter n: ");
    scanf("%d",&n);

    // get the data needed
    struct runner data[n];
    for (int i=0; i<n ; i++)
    {
        printf("Enter first name of the runner NO.%d: ",i+1);
        scanf("%s",data[i].firstName);
        printf("Enter last name of the runner NO.%d: ",i+1);
        scanf("%s",data[i].lastName);
        printf("Enter ID of the runner NO.%d: ",i+1);
        scanf("%s",data[i].ID);

        data[i].record = (struct time *)malloc(sizeof(struct time)); // Allocate memory for record

        printf("Enter min of record of all time of the runner NO.%d: ",i+1);
        scanf("%d",&data[i].record->min);
        printf("Enter sec of record of all time of the runner NO.%d: ",i+1);
        scanf("%d",&data[i].record->sec);
        printf("Enter min of running time of the runner NO.%d: ",i+1);
        scanf("%d",&data[i].runningTime.min);
        printf("Enter sec of running time of the runner NO.%d: ",i+1);
        scanf("%d",&data[i].runningTime.sec);

    }

    // find the winner
    int winner = 0;
    for (int i = 1; i < n ; i++) {
        if (compareTimes(data[i].runningTime, data[winner].runningTime) == 0) {
            winner = i;
        }
    }

    // check if he/she could break his/her own record
    // 1 means could
    int recordCheck = 0;
    if (compareTimes(data[winner].runningTime, *data[winner].record) == 0)
    {
        recordCheck = 1;
    }

    // check if he/she could break others records
    // 1 means could
    int checkOthers = 1;
    for (int i = 0; i < n; i++) {
        if (i != winner && compareTimes(data[winner].runningTime, *data[i].record) == 1) {
            checkOthers = 0;
            break;
        }
    }
    // printing the information of the winner
    printf("The winner is: %s %s\n",data[winner].firstName,data[winner].lastName);

    if (recordCheck == 0)
        printf("COULD NOT break his/her own record.\n");
    else
        printf("COULD break his/her own record.\n");


    if (checkOthers == 0)
        printf("COULD NOT break others records.\n");
    else
        printf("COULD break others records.\n");


    // deleting the winner from the list
    for (int i=winner + 1 ; i<n ; i++){
        data[i-1] = data[i];
    }


    // print information of other participants
    int remain = n-1;
    int best = 1;
    int count = 2;
    printf("Information of others:(sorted by time)\n");
    printf("      FIRST NAME                     LAST NAME                      ID         RUNNING TIME    RECORD\n");
    int i = 0;
    while (i < remain)
    {
        for (int j = 0 ; j < remain ; j++)
        {
            if (j != i && compareTimes(data[i].runningTime,data[j].runningTime) == 1)
            {
                best = 0;
                break;
            }
        }

        if (best == 1)
        {
            // printing the information of others
            printf("%3d : %-30s %-30s %-10s ",count,data[i].firstName,data[i].lastName,data[i].ID);
            printf("%-2dmin %-2dsec     %-2dmin %-2dsec\n",data[i].runningTime.min,data[i].runningTime.sec,data[i].record->min,data[i].record->sec);
            count ++;
            // deleting the best from the list
            for (int k = i+1 ; k < remain ; k++)
            {
                data[k-1] = data[k];
            }
            remain --;
            i = 0;

        }
        else
        {
            i ++;
        }
        best = 1;
        
    }

    for (int i = 0; i < n; i++) {
        free(data[i].record);
    }
    

    return 0;
}